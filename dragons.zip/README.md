
# Dragons sample app

## Run the app with Spring Boot Command Line

```bash
mvn spring-boot:run
```

## Run tests

```bash
mvn test
```
